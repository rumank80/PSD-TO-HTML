$(document).ready(function(){
  $('.venobox').venobox({
      border:'10px',
  }); 
});
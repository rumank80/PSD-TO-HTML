$(document).ready(function () {
    //slider 01 js
    $('.slider1').slick({
        infinite: true,
        slidesToShow: 1,
        slidesToScroll:1,
        arrows:true,
        autoplay:false,
        speed:500,
        fade:true,
        autoplaySpeed:1000,
        prevArrow:'.arrow_left',
        nextArrow:'.arrow_right',
        dots:true,
    });
});
$(document).ready(function (){
      $('.slider_2').slick({
        infinite: true,
        slidesToShow: 1,
        slidesToScroll:1,
        arrows:false, 
        autoplay:true,
        speed:500,
        fade:true,
        autoplaySpeed:1000,
        
    });
});


$(document).ready(function () {
    //slider 01 js
$('.slider3').slick({
  infinite: true,
  slidesToShow: 3,
  slidesToScroll:1,
    arrows:false,
});
});


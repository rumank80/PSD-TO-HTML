$(document).ready(function(){
    $('.carousel').carousel({
  interval: 300
})
})
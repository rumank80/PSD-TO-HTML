$(document).ready(function(){
  $('.slider').bxSlider();
});
